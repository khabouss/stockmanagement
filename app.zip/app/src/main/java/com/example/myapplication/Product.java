package com.example.myapplication;

public class Product {

    String productName, productPrice, productQuantity;

    public String getProductName() {
        return productName;
    }

    public String getProductPrice() {
        return productPrice;
    }

    public String getProductQuantity() {
        return productQuantity;
    }
}
