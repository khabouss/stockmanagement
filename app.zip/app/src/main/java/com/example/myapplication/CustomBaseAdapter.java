package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.TextView;

public class CustomBaseAdapter extends BaseAdapter {

    Context context;
    String[] names;
    String[] prices;
    LayoutInflater layoutInflater;


    public CustomBaseAdapter(Context ctx, String[] names, String[] prices){
        this.context = ctx;
        this.names = names;
        this.prices = prices;
        this.layoutInflater = LayoutInflater.from(ctx);
    }

    @Override
    public int getCount() {
        return names.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        convertView = layoutInflater.inflate(R.layout.activity_custom_list_view, null);
        TextView productName = convertView.findViewById(R.id.productNameLS);
        TextView productPrice = convertView.findViewById(R.id.productPriceLS);
        productName.setText(names[position]);
        productPrice.setText(prices[position]);
        return convertView;
    }
}
