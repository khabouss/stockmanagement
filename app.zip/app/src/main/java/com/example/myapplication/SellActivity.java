package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class SellActivity extends AppCompatActivity {

    private StringBuilder codes;
    private StringBuilder names;
    private StringBuilder prices;
    private CardView cardView;
    private View background;
    private ListView listView;
    private TextView commandTotal;
    private TextView commandTicket;
    private float total;
    private boolean twise = false;
    private boolean busy;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sell2);

        total = 0;

        Button newProduct = findViewById(R.id.newProduct);
        Button confirmCommand = findViewById(R.id.confirmCommand);
        listView = findViewById(R.id.listOfProducts);
        commandTotal = findViewById(R.id.commandTotal);
        commandTicket = findViewById(R.id.commandTicket);
        cardView = findViewById(R.id.sellAcCardView);
        names = new StringBuilder("");
        background = findViewById(R.id.backgroundColor);
        prices  = new StringBuilder("");
        codes = new StringBuilder("");

        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
        String date = df.format(c);

        FirebaseDatabase database = FirebaseDatabase.getInstance("https://stockmanager-1e3f7-default-rtdb.europe-west1.firebasedatabase.app/");
        DatabaseReference myRef = database.getReference("Days").child(date);
        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String ticket = dataSnapshot.child("Tickets").getValue(String.class);
                if (ticket == null)
                    commandTicket.setText("Ticket: 0");
                else {
                    int ticketNum = Integer.parseInt(ticket);
                    String ticketValue = "Ticket: " + (++ticketNum);
                    commandTicket.setText(ticketValue);
                }

            }
            @Override
            public void onCancelled(DatabaseError error) {
                // Failed to read value
            }
        });

        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(CaptureAct.class);
        integrator.setOrientationLocked(false);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Scanning Code");
        integrator.initiateScan();

        newProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                integrator.initiateScan();
            }
        });
        confirmCommand.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance("https://stockmanager-1e3f7-default-rtdb.europe-west1.firebasedatabase.app/");
                DatabaseReference myRef = database.getReference("Days").child(date);
                DatabaseReference stockRef = database.getReference("Stock");
                String ticketValue = commandTicket.getText().toString().split(" ")[1];
                myRef.child("Tickets").setValue(ticketValue);
                myRef.child("Total").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                        if (dataSnapshot.getValue() == null){
                            dataSnapshot.getRef().setValue(String.valueOf(total));
                        }else{
                            String val = dataSnapshot.getValue(String.class);
                            val = "" + (Float.parseFloat(val) + total);
                            dataSnapshot.getRef().setValue(val);
                        }
                        stockRef.addListenerForSingleValueEvent(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                String[] barcodes = codes.toString().split("\n"); // when the same product bought multiple time it only take away one
                                for (String code : barcodes){
                                    String val = dataSnapshot.child(code).child("productQuantity").getValue(String.class);
                                    val = "" + (Integer.parseInt(val) - 1);
                                    dataSnapshot.child(code).child("productQuantity").getRef().setValue(val);
                                }
                                cardView.setVisibility(View.VISIBLE);
                                background.setVisibility(View.VISIBLE);
                                new Handler().postDelayed(new Runnable() {
                                    @Override
                                    public void run() {
                                        finish();
                                    }
                                }, 3000);
                            }
                            @Override
                            public void onCancelled(@NonNull DatabaseError databaseError) {

                            }
                        });
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError databaseError) {

                    }
                });
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null){
            String codeValue = result.getContents();
            if (codeValue != null){// if product is not in stock
                codes.append(codeValue).append("\n");
                FirebaseDatabase database = FirebaseDatabase.getInstance("https://stockmanager-1e3f7-default-rtdb.europe-west1.firebasedatabase.app/");
                DatabaseReference myRef = database.getReference("Stock").child(codeValue);
                myRef.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        String name = dataSnapshot.child("productName").getValue(String.class);
                        String price = dataSnapshot.child("productPrice").getValue(String.class);
                        assert price != null;
                        total += Float.parseFloat(price);
                        names.append(name).append("\n");
                        prices.append(price).append("\n");
                        String[] namesarr = names.toString().split("\n");
                        String[] pricesarr = prices.toString().split("\n");
                        CustomBaseAdapter customBaseAdapter = new CustomBaseAdapter(getApplicationContext(), namesarr, pricesarr);
                        listView.setAdapter(customBaseAdapter);
                        String totalString = total + "DH";
                        commandTotal.setText(totalString);
                    }
                    @Override
                    public void onCancelled(DatabaseError error) {
                        // Failed to read value
                    }
                });
            }
        }else{
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}