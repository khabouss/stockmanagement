package com.example.myapplication;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.Arrays;

public class NewStock extends AppCompatActivity {

    private TextView productBarcode;
    private EditText productName;
    private EditText productQuantity, productPrice, productPrice0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_stock);

        productBarcode = findViewById(R.id.productBarcode);
        productName = findViewById(R.id.productName);
        productQuantity = findViewById(R.id.productQuantity);
        productPrice = findViewById(R.id.productPrice);
        productPrice0 = findViewById(R.id.productPrice0);
        Button cancelStock = findViewById(R.id.cancelStock);
        Button confirmStock = findViewById(R.id.confirmStock);

        confirmStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                FirebaseDatabase database = FirebaseDatabase.getInstance("https://stockmanager-1e3f7-default-rtdb.europe-west1.firebasedatabase.app/");
                DatabaseReference myRef = database.getReference("Stock").child(productBarcode.getText().toString());
                myRef.child("productName").setValue(productName.getText().toString());
                myRef.child("productQuantity").setValue(productQuantity.getText().toString());
                myRef.child("productPrice").setValue(productPrice.getText().toString());
                myRef.child("productPrice0").setValue(productPrice0.getText().toString());
                NewStock.super.onBackPressed();
            }
        });

        cancelStock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NewStock.super.onBackPressed();
            }
        });

        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setCaptureActivity(CaptureAct.class);
        integrator.setOrientationLocked(false);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.ALL_CODE_TYPES);
        integrator.setPrompt("Scanning Code");
        integrator.initiateScan();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null){
            if (result.getContents() != null){
                productBarcode.setText(result.getContents());
            }
        }else{
            super.onActivityResult(requestCode, resultCode, data);
            NewStock.super.onBackPressed();
        }
    }
}